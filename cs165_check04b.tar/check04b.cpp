/*********************************************************************
 * File: check04b.cpp
 * Purpose: contains the main method to exercise the Date class.
 *********************************************************************/

#include "date.h"

#include <iostream>
using namespace std;

int main()
{
   int month, day, year;
   // prompt for month, day, year
   cout << "Month: ";
   cin >> month;
   cout << "Day: ";
   cin >> day;
   cout << "Year: ";
   cin >> year;

   cout << endl;
   // create a Date object
   Date userDate;

   // set its values
   userDate.set(month,day,year);
   // call each display function
   userDate.displayAmerican();
   userDate.displayEuropean();
   userDate.displayISO();


   return 0;
}
