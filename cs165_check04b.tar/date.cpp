/********************************************************************
 * File: date.cpp
 * Purpose: Holds the implementation of the Date class methods.
 ********************************************************************/
#include "date.h"
#include <iostream>
using namespace std;

// Put your method bodies here...

      /********************************************************************
       * Accepts a month, day, and year, and sets the member variables
       * 
       ********************************************************************/
      
      void Date::set(int month, int day, int year)
      {
         this->month = month;
         this->day = day;
         this->year = year ;
      }

      /********************************************************************
       * Displays the date in the format: mm/dd/yyyy
       * 
       ********************************************************************/
      void Date::displayAmerican()
      {
         cout << month << "/" << day << "/" << year << endl ;
      } 

      /********************************************************************
       * Displays the date in the format: dd/mm/yyyy 
       * 
       ********************************************************************/
      void Date::displayEuropean()
      {
         cout << day << "/" << month << "/" << year << endl ;
      }

      /********************************************************************
       * Displays the date in the format: yyyy-mm-dd 
       * 
       ********************************************************************/      
      void Date::displayISO()
      {
         cout << year << "-" << month << "-" << day << endl ;
      }