/***********************
 * File: money.cpp
 ***********************/

#include <iostream>
#include <iomanip>
using namespace std;

#include "money.h"

/*****************************************************************
 * Function: prompt
 * Purpose: Asks the user for values for dollars and cents
 *   and stores them.
 ****************************************************************/
void Money :: prompt()
{
   int dollars;
   int cents;

   cout << "Dollars: ";
   cin >> dollars;

   cout << "Cents: ";
   cin >> cents;

   setDollars(dollars);
   setCents(cents);
}

/*****************************************************************
 * Function: setDollars
 * Purpose: setter takes user input and updates the Dollars member
 ****************************************************************/
void Money :: setDollars(int dollars)
{
   this->dollars = dollars;
   
      if(dollars < 0)
      {
         this->dollars = -dollars;
      }
      
}

/*****************************************************************
 * Function: setCents
 * Purpose: setter takes user input and updates the Cents member
 ****************************************************************/
void Money :: setCents(int cents)
{
   this->cents = cents;

   if(cents < 0)
   {
      this->cents = -cents;
   }
   
}

/*****************************************************************
 * Function: getDollars
 * Purpose: getter to retreive input from user for dollars
 ****************************************************************/
int Money :: getDollars() const
{
   return dollars;
}

/*****************************************************************
 * Function: getCents
 * Purpose: getter to retreive input from user for cents
 ****************************************************************/
int Money :: getCents() const
{
   return cents;
}

/*****************************************************************
 * Function: display
 * Purpose: Displays the value of the money object.
 ****************************************************************/
void Money :: display() const 
{
   cout << "$" << getDollars() << ".";
   cout << setfill('0') << setw(2) << getCents();
}
