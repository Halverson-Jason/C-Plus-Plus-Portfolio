/***************************************************************
 * File: assign04.cpp
 * Author: Jason Halverson
 * Purpose: Contains the main function to test the Product class.
 ***************************************************************/

#include <iostream>
#include <string>
using namespace std;

#include "product.h"

int main()
{
   // Declare your Product object here
   
   Product MyProduct;

   // Call your prompt function here
   MyProduct.prompt();
   MyProduct.getTotalPrice();

   cout << endl;
   cout << "Choose from the following options:\n";
   cout << "1 - Advertising profile\n";
   cout << "2 - Inventory line item\n";
   cout << "3 - Receipt\n";
   cout << endl;
   cout << "Enter the option that you would like displayed: ";

   int choice;
   cin >> choice;

   cout << endl;

   switch(choice)
   {
      case 1 :
         // Call your display advertising profile function here
         MyProduct.displayAdvertising();
         break;
      case 2:
         // Call your display inventory line item function here
         MyProduct.displayLineItem();
         break;
      case 3:
         // Call your display receipt function here
         MyProduct.displayReceipt();
         break;
   }

   return 0;
}
