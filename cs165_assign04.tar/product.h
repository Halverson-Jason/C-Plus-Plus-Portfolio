/***************************************************************
 * File: product.h
 * Author: Jason Halverson
 * Purpose: Contains the definition of the Product class
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H
#include <string>

// put your class definition here

class Product 
{
   
private:
   // private member variables
   std::string name;
   double basePrice;
   float weight;
   std::string description;
   double salesTax;
   double shippingCost;
   double totalPrice;

   // private member methods
   void getSalesTax();
   void getShippingCost();

public:
   // private member methods
   void prompt();
   void getTotalPrice();
   void displayAdvertising();
   void displayLineItem();
   void displayReceipt();

};

#endif
