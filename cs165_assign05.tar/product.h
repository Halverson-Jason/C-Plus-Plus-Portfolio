/***************************************************************
 * File: product.h
 * Author: Jason Halverson
 * Purpose: Contains the definition of the Product class
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H
#include <iostream>
using namespace std;
// put your class definition here

class Product 
{
   
private:
   // private member variables
   string name;
   double basePrice;
   double weight;
   string description;
   double salesTax;
   double shippingCost;
   double totalPrice;

   // private member methods
   void setSalesTax();
   void setShippingCost();
   

public:
   // private member methods
   void prompt();
   double getTotalPrice();
   void setTotalPrice();
   void displayAdvertising();
   void displayInventory();
   void displayReceipt();

   // week 5 additions

   string getName();
   void setName(string name);
   string getDescription();
   void setDescription(string description);
   double getBasePrice();
   void setBasePrice(double basePrice);
   double getWeight();
   void setWeight(double weight);
   double getShippingCost();

   // constructors
   Product();
   Product(string name, string description, double basePrice, double weight);

};

#endif
