// File: customer.h

#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "address.h"

// put your Customer class here
class Customer 
{
   private:
      string name;
      Address address;

   public:
      string getName() const;
      void setName(string name);
      Address getAddress() const;
      void setAddress(Address address);
      void display() const;

      // constructors

      Customer();
      Customer(string name, Address address);
};
#endif
