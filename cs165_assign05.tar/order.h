// File: order.h

#ifndef ORDER_H
#define ORDER_H

#include <iostream>
using namespace std;

#include "product.h"
#include "customer.h"


// Put your Order class here
class Order
{
   private:
      Product product;
      int quantity;
      Customer customer;
      double totalPrice;

   public:
      Product getProduct();
      void setProduct(Product product);
      int getQuantity();
      void setQuantity(int quantity);
      Customer getCustomer();
      void setCustomer(Customer customer);

      string getShippingZip();
      double getTotalPrice();
      void setTotalPrice();
      void displayShippingLabel();
      void displayInformation();

      //constructors
      Order();
      Order(Product product, int quantity, Customer customer);


};

#endif
