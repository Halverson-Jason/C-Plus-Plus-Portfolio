// File: address.h
#include <iostream>
using namespace std;

#ifndef ADDRESS_H
#define ADDRESS_H

// Put your Address class here

class Address 
{
   private:
      string street;
      string city;
      string state;
      string zip;

   public:
      string getStreet() const;
      void setStreet(string street);
      string getCity() const;
      void setCity(string city);
      string getState() const;
      void setState(string state);
      string getZip() const;
      void setZip(string zip);
      void display() const;

      // constructors
      Address();
      Address(string street, string city, string state, string zip);
};

#endif
