// File: customer.cpp
#include <iostream>
using namespace std;

#include "customer.h"

// constructors

/***************************************************************
 * default constructor
 * sets name and address values
 ***************************************************************/
Customer :: Customer()
{
   name = "unspecified";
   address;
}

/***************************************************************
 * non-default constructor
 * gets user input for name and address values
 ***************************************************************/
Customer :: Customer(string name, Address address)
{
   setName(name);
   setAddress(address);
}

// Put the method bodies for your customer class here

/***************************************************************
 * getName
 * getter for name value
 ***************************************************************/
string Customer :: getName() const
{
   return name;
}

/***************************************************************
 * setName
 * settter for name value
 ***************************************************************/
void Customer :: setName(string name)
{
   this->name = name;
}

/***************************************************************
 * getAddress
 * getter for address value
 ***************************************************************/
Address Customer :: getAddress() const
{
   return address;
}

/***************************************************************
 * setAddress
 * setter for Address value
 ***************************************************************/
void Customer :: setAddress(Address address)
{
   this->address = address;
}

/***************************************************************
 * display
 * displays values in desired format
 ***************************************************************/
void Customer :: display() const
{
   cout << name << endl << address.getStreet() << endl << address.getCity() << ", " << address.getState() << " " << address.getZip() << endl;
}