// File: address.cpp
#include "address.h"

/***************************************************************
 * default constructor
 * Sets street, zip , city and state values
 ***************************************************************/
Address :: Address()
{
   street = "unknown";
   zip = "00000";
   city = "";
   state = "";
}
/***************************************************************
 * non-default constructor
 * allows user to set street, zip , city and state values
 ***************************************************************/
Address :: Address(string street, string city, string state, string zip)
{
   setStreet(street);
   setCity(city);
   setState(state);
   setZip(zip);
}

// Put your method bodies for the address class here

/***************************************************************
 * getStreet
 * getter for street value
 ***************************************************************/
string Address::getStreet() const
   {
      return street;
   }

/***************************************************************
 * setStreet
 * setter for street value
 ***************************************************************/
void Address::setStreet(string street)
   {
      this->street = street;
   }

/***************************************************************
 * getCity
 * getter for city value
 ***************************************************************/
string Address::getCity() const
   {
      return city;
   }

/***************************************************************
 * setCity
 * setter for city value
 ***************************************************************/
void Address::setCity(string city)
   {
      this->city = city;
   }

/***************************************************************
 * getState
 * getter for state value
 ***************************************************************/
string Address::getState() const
   {
      return state;
   }

/***************************************************************
 * setState
 * setter for state value
 ***************************************************************/
void Address::setState(string state)
   {
      this->state = state;
   }

/***************************************************************
 * setAddress
 * getter for address value
 ***************************************************************/
string Address::getZip() const
   {
      return zip;
   }

/***************************************************************
 * setZip
 * setter for zip value
 ***************************************************************/
void Address::setZip(string zip)
   {
      this->zip = zip;
   }

/***************************************************************
 * display
 * displays values in a desires format.
 ***************************************************************/
void Address::display() const
   {
      cout << street << endl << city << ", " << state << " " << zip << endl;
   }

