// File: order.cpp

#include "order.h"

// constructors

/***************************************************************
 * default constructor
 * sets the quantity , product and customer values
 ***************************************************************/
Order :: Order()
{
   quantity = 0;
   product;
   customer;

}

/***************************************************************
 * non-default constructor
 * allows user to set product , quantity , customer
 ***************************************************************/
Order :: Order(Product product, int quantity, Customer customer)
{
   setProduct(product);
   setQuantity(quantity);
   setCustomer(customer);
   setTotalPrice();
}

// Put your the method bodies for your order class here
/***************************************************************
 * getProduct
 * getter for product value
 ***************************************************************/
Product Order :: getProduct()
{
   return product;
}

/***************************************************************
 * setProduct
 * setter for product value
 ***************************************************************/
void Order :: setProduct(Product product)
{
   this->product = product;
}

/***************************************************************
 * getQuantity
 * getter for quantity value
 ***************************************************************/
int Order :: getQuantity()
{
   return quantity;
}

/***************************************************************
 * setQuantity
 * setter for quantity value
 ***************************************************************/
void Order :: setQuantity(int quantity)
{
   this->quantity = quantity;
}

/***************************************************************
 * getCustomer
 * getter for customer value
 ***************************************************************/
Customer Order :: getCustomer()
{
   return customer;
}

/***************************************************************
 * setCustomer
 * setter for customer value
 ***************************************************************/
void Order :: setCustomer(Customer customer)
{
   this->customer = customer;
}

// call a class within a class

/***************************************************************
 * getShippingZip
 * getter for customer zip
 ***************************************************************/
string Order :: getShippingZip()
{
   return customer.getAddress().getZip();
}

/***************************************************************
 * getTotalPrice
 * updates total price and getter for price
 ***************************************************************/
double Order :: getTotalPrice()
{
   setTotalPrice();
   return totalPrice;
}

/***************************************************************
 * setTotalPrice
 * setter for totalPrice value
 ***************************************************************/
void Order :: setTotalPrice()
{
   totalPrice = product.getTotalPrice() * quantity;
}

/***************************************************************
 * displayShippingLabel
 * displays a shipping label for user
 ***************************************************************/
void Order :: displayShippingLabel()
{
   cout << customer.getName() << endl << customer.getAddress().getStreet()
      << endl << customer.getAddress().getCity() << ", " 
      << customer.getAddress().getState() << " " << customer.getAddress().getZip() << endl;
}

/***************************************************************
 * displayInformation
 * displays the customer order info in desired output
 ***************************************************************/
void Order :: displayInformation()
{
   cout << customer.getName() << endl << product.getName() << endl
   << "Total Price: $" << totalPrice << endl ;
}