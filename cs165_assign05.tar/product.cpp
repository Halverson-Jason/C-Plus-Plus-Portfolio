/***************************************************************
 * File: product.cpp
 * Author: Jason Halverson
 * Purpose: Contains the method implementations for the Product class.
 ***************************************************************/

#include "product.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#define taxRate 0.06
#define minWeight 5
// constructors

Product :: Product()
{
      name = "none";
      description = "";
      weight = 0;
      basePrice = 0;
}

Product :: Product(string name, string description, double basePrice, double weight)
{
      setName(name);
      setDescription(description);
      setWeight(weight);
      setBasePrice(basePrice);
}

// put your method bodies here

/***************************************************************
 * prompts for the name, base price, weight, and description, 
 * and sets these values in the current object
 ***************************************************************/
void Product :: prompt()
{
   bool invalidPrice;
   cout << "Enter name: ";
   getline(cin, name);
   cout << "Enter description: ";
   getline(cin, description);
   cout << "Enter weight: ";
   cin >> weight;
   do
      {
         cout << "Enter price: ";
         cin >> basePrice;

         if (cin.fail())
            {
               cin.clear();
               cin.ignore(256, '\n');
               invalidPrice = true;
            }

         else
         {
          invalidPrice = false;
         }
      } while(invalidPrice || (basePrice < 0));

}

/***************************************************************
 * receives base price
 * returns 6% of the base price
 ***************************************************************/
void Product :: setSalesTax()
{
  this->salesTax = basePrice * taxRate;
}

/***************************************************************
 * turns a flat rate of $2.00 if the item is less than 5 lbs, 
 * and $2.00 + $0.10 per pound over 5 lbs
 ***************************************************************/
void Product::setShippingCost()
{
   if ( weight < minWeight )
   {
      this->shippingCost = 2;
   }
   
   else
   {
      double weightOver = weight - minWeight;
      this->shippingCost = (0.1 * weightOver) + 2 ;
   }
}

double Product :: getShippingCost()
{
      return shippingCost;
}

/***************************************************************
 * receives basePrice , salesTax, and shippingCost
 * uses other methods to return a total price
 ***************************************************************/
double Product::getTotalPrice()
{
   return totalPrice;
}

/***************************************************************
 * displays the name, base price, and description
 * in the desired format
 ***************************************************************/
void Product::displayAdvertising()
{
   // set cout precision
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);

   cout << name << " - $" << basePrice << endl << "(" 
   << description << ")" << endl;
}

/***************************************************************
 * displays the base price, name, and weight
 * in the desired format
 ***************************************************************/
void Product::displayInventory()
{
   // set cout precision
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);
   
   cout << "$" << basePrice << " - " << name << " - " ;
   cout.precision(1);
   cout << weight << " lbs" << endl;
}

/***************************************************************
 * displays the name, base price, sales tax, shipping cost, 
 * and total price in the desired format
 ***************************************************************/
void Product::displayReceipt()
{
   // set cout precision
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);
   
   cout << name << endl ;
   cout << "  Price:" << setw(10) << "$"  << setw(8) 
   << basePrice << endl;

   cout << "  Sales tax:" << setw(6) << "$"  << setw(8) 
   << salesTax << endl;
   
   cout << "  Shipping cost:" << setw(2) << "$"  << setw(8) 
   << shippingCost << endl;
   
   cout << "  Total:" << setw(10) << "$"  << setw(8) 
   << totalPrice << endl;
}
/***************************************************************
 * Getter for
 * name
 ***************************************************************/
string Product :: getName()
{
      return name;
}

/***************************************************************
 * Setter for
 * name
 ***************************************************************/
void Product :: setName(string name)
{
      this->name = name;
}

/***************************************************************
 * Getter for
 * description
 ***************************************************************/
string Product :: getDescription()
{
      return description;
}

/***************************************************************
 * Setter for
 * description
 ***************************************************************/
void Product :: setDescription(string description)
{
      this->description = description;
}

/***************************************************************
 * Getter for
 * basePrice
 ***************************************************************/
double Product :: getBasePrice()
{
      return basePrice;
}

/***************************************************************
 * Setter for
 * basePrice
 ***************************************************************/
void Product :: setBasePrice(double basePrice)
{
      this->basePrice = basePrice;
      setSalesTax();
      setShippingCost();
      setTotalPrice();
}
/***************************************************************
 * Setter for
 * totalPrice
 ***************************************************************/
void Product :: setTotalPrice()
{
   this->totalPrice = basePrice + salesTax + shippingCost;
}
/***************************************************************
 * Getter for
 * weight
 ***************************************************************/
double Product :: getWeight()
{
      return weight;
}

/***************************************************************
 * Setter for
 * weight
 ***************************************************************/
void Product :: setWeight(double weight)
{
      this->weight = weight;
}
